package com.example.restaurantmanagementapp

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Splash_Screen : AppCompatActivity() {
    private val SPLASH_DELAY = 3000L // 3 seconds

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_splash_screen)

        try {
            // Set up the layout
            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }

            // Load and start the fade-in animation
            val fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in)
            val mainLayout = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.main)
            mainLayout.startAnimation(fadeIn)

            // Schedule the transition to Intro Screen
            Handler(Looper.getMainLooper()).postDelayed({
                startIntroScreen()
            }, SPLASH_DELAY)

        } catch (e: Exception) {
            // If there's any error, immediately go to Intro Screen
            startIntroScreen()
        }
    }

    private fun startIntroScreen() {
        if (!isFinishing) {
            try {
                val intent = Intent(this@Splash_Screen, Intro_Screen::class.java)
                startActivity(intent)
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out)
                finish()
            } catch (e: Exception) {
                Toast.makeText(this, "Error launching intro screen", Toast.LENGTH_SHORT).show()
            }
        }
    }
}